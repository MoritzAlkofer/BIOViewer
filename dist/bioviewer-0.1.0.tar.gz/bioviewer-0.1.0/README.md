# BIOViewer


## Installation
You can install this library via pip:

``` bash
pip install BIOViewer
```

### Usage

This library is designed to help you build visualization tools for Biosignals. You can use the prebuilt viewers or use the basic modules to configure your own!

to get a demo of how the prebuilt modules work, check out the demo.ipynb notebook!


